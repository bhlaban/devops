# Description

The resource is used to wait for a drive to be mounted and become available.
